define(function(require) {
   'use strict';

   var
      _          = require('underscore'),
      Component  = require('Component'),
      template   = require('/template/mainView');

   return Component.extend({

      template: template,

      filterState: function(state) {
        return
      } 
   });
});